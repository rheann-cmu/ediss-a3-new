package com.cmu.crmapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmappApplicationTests {

	@Test
	void contextLoads() {
	}

}
